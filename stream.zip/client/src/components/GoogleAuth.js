import React, { Component } from 'react';
import {connect} from 'react-redux';
import {onAuthChange, onSignIn, onSignOff} from '../actions/index';

class GoogleAuth extends Component {
    constructor(props) {
        super(props);
    }
    
    componentDidMount() {
        console.log(window.gapi);
        window.gapi.load('client', () => {
            window.gapi.client.init({
                clientId: '808863089220-ee8jlni8cdvjv49s7sgo83ath5no6ups.apps.googleusercontent.com',
                scope: 'email'
            }).then(() => {
                this.auth = window.gapi.auth2.getAuthInstance();
                this.authHandler(this.auth.isSignedIn.get());
                this.auth.isSignedIn.listen(this.authHandler);
            }
            )
        })
    }

    authHandler = (isSignedIn) => {
        console.log("authhandler", isSignedIn)
        if (isSignedIn) {
            this.props.onSignIn();
        } else {
            this.props.onSignOff();
        }
    }
    onSignInClick = () => {
        this.auth.signIn({
            prompt: "select_account"
        });
    }
    onSignOutClick = () => {
        this.auth.signOut();
    }
    renderHelper() {
        if (this.props.isSignedIn === null) {
            return "";
        } else if (this.props.isSignedIn === true) {
            return (
                <button className="ui red labeled icon button" onClick={this.onSignOutClick} >
                <i className="icon google"></i>
                Sign Out
              </button>
            )
        } else {
            console.log("renderhelper else")
            return (
                <button className="ui red labeled icon button" onClick={this.onSignInClick} >
                <i className="icon google"></i>
                Sign in with google
              </button>
            )
        }
    }
    render() {
       return (
           <div>
               {this.renderHelper()}
           </div>
       )
    }
}

function mapStateToProps({auth}) {
    console.log("mapstatetoprops", auth)
    return {
        isSignedIn: auth.isSignedIn
    }
}
export default connect(mapStateToProps, {onSignIn, onSignOff})(GoogleAuth);