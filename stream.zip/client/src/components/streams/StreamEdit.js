import React, { Component } from 'react'

const StreamEdit = () => {
    return (
        <div>StreamEdit</div>
    )
}

export default StreamEdit;