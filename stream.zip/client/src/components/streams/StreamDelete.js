import React, { Component } from 'react'

const StreamDelete = () => {
    return (
        <div>StreamDelete</div>
    )
}

export default StreamDelete;