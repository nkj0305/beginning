import React, { Component } from 'react'

const StreamList = () => {
    return (
        <div>StreamList</div>
    )
}

export default StreamList;