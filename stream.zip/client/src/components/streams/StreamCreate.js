import React from 'react'
import { Field, reduxForm } from 'redux-form'

class StreamCreate extends React.Component {
    render() {
        const { handleSubmit, pristine, reset, submitting } = this.props
        return (
            <form className="ui form" onSubmit={handleSubmit}>
                <div className="field">
                    <label>Title</label>
                    <div>
                        <Field
                            name="firstName"
                            component="input"
                            type="text"
                            placeholder="First Name"
                        />
                    </div>
                </div>
                <div className="field">
                    <label>Description</label>
                    <div>
                        <Field name="notes" component="textarea" rows="2" />
                    </div>
                </div>
                <div >
                    <button className="ui button" type="submit" disabled={pristine || submitting}>
                        Submit
                    </button>
                </div>
            </form>
        )
    }
}

export default reduxForm({
    form: 'simple' // a unique identifier for this form
})(StreamCreate)