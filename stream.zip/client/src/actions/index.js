export function onAuthChange() {
    return {
        type: 'AUTH_CHANGE'
    }
}

export function onSignIn() {
    return {
        type: 'SIGN_IN'
    }
}

export function onSignOff() {
    return {
        type: 'SIGN_OFF'
    }
}