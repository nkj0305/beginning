import {combineReducers} from 'redux';
import SignInStatus from './SignInStatus';

const reducers = combineReducers({
    auth: SignInStatus
});

export default reducers