export default function SignInStatus(state = {isSignedIn: null}, action ) {
    console.log("action type", action.type)
    switch (action.type) {
        case "SIGN_IN" : return { ...state, isSignedIn: true };break
        case "SIGN_OFF" : return { ...state, isSignedIn: false}
        default: return state
    }
}